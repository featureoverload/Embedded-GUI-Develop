#! /usr/bin/python3

#
# file name: setup.py
# author   : Huaxing Lin
#

from distutils.core import setup

setup (
	name         = 'cgiutils',
	version      = '1.0.0',
	py_modules   = ['cgiutils'],
	author       = 'joseph',
	author_email = 'joseph.lin@aliyun.com',
	url          = 'none',
	description  = 'none',
	)