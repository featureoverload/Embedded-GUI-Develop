

## how to use:

`USER@HostName:<path of dir-echo2tmnl>\$ python3 setup.py sdist`

`USER@HostName:<path of dir-echo2tmnl>\$ sudo python3 setup.py install`

```pyt
$ python3
Python 3.x.x 
>>> from echo2tmnl import echo2
>>>
>>> echo2("/dev/ttyS0", "heheda" )
>>>

```





