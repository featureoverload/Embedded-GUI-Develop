#
#
#

from distutils.core import setup

setup (
	name         = 'echo2tmnl',
	version      = '0.0.2',
	py_modules   = ['echo2tmnl'],
	author       = 'joseph',
	author_email = 'joseph.lin@aliyun.com',
	url          = 'none',
	description  = 'none',
	)
